Vista previa:

![image](https://github.com/user-attachments/assets/5d939123-c63c-4db5-9417-af255fb97d3b)

Uso:

1.- Descargar e instalar nodejs. Si no está instalado, ir a: `https://nodejs.org/es`.

2.- Descargar el zip y descomprimirlo, de este mismo repositorio, hablo.

3.- Ejecutar `>npm install express` en la ruta del fichero `server.js`.

4.- Ejecutar `>npm install socket.io` en la ruta del fichero `server.js`.

5.- Ejecutar comando `>node server.js` en la ruta del fichero `server.js`.

6.- Abrir `>localhost:8000` o por la ip del servidor sobre el q se esté ejecutando este programa `192.168.XXX.XXX`.

7.- WASD para moverse.

8.- Q para pegar.

9.- Ratón para apuntar.

10.- Quien tenga esta herramienta o script de nodejs o no, no necesito dinero ni fama, puede copiar mi código x si le sirve de distracción, tampoco incluye anuncios.
